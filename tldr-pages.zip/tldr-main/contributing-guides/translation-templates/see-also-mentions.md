# Mentioning related pages

Oftentimes when you have related commands, be it tools that you use in tandem or commands that are similar
to the one in the current page, it is nice to leave a hit of it existing in the header.
An example of this is `top` where it's good to have mentions of alternatives like `atop`, `glances`,
`btop` and `btm`.
In order to notify the user that such pages exist, we put a little notice in the base command's description.
This file contains the translation templates of this notice.

[en](#en) •
[ar](#ar) •
[bg](#bg) •
[bn](#bn) •
[bs](#bs) •
[ca](#ca) •
[cs](#cs) •
[da](#da) •
[de](#de) •
[el](#el) •
[es](#es) •
[fa](#fa) •
[fi](#fi) •
[fr](#fr) •
[hi](#hi) •
[id](#id) •
[it](#it) •
[ja](#ja) •
[ko](#ko) •
[lo](#lo) •
[ml](#ml) •
[nb](#nb) •
[ne](#ne) •
[nl](#nl) •
[no](#no) •
[pl](#pl) •
[pt_BR](#pt_br) •
[pt_PT](#pt_pt) •
[ro](#ro) •
[ru](#ru) •
[si](#si) •
[sr](#sr) •
[sv](#sv) •
[ta](#ta) •
[th](#th) •
[tr](#tr) •
[uk](#uk) •
[uz](#uz) •
[zh](#zh) •
[zh_TW](#zh_tw)

---

### en

```markdown
> See also: `example`.
```

---

### ar

```markdown
> انظر أيضًا: `example`.
```

---

### bg

```markdown
> Виж също: `example`.
```

---

### bn

```markdown
> আরও দেখুন: `example`।
```

---

### bs

```markdown
> Pogledajte isto: `example`.
```

---

### ca

```markdown
> Vegeu també: `example`.
```

---

### cs

```markdown
> Viz také: `example`.
```

---

### da

```markdown
> Se også: `example`.
```

---

### de

```markdown
> Siehe auch: `example`.
```

---

### el

```markdown
> Δείτε επίσης: `example`.
```

---

### es

```markdown
> Vea también: `example`.
```

---

### fa

```markdown
> همچنین : `example`.
```

---

### fi

```markdown
> Katso myös: `example`.
```

---

### fr

```markdown
> Voir aussi : `example`.
```

---

### hi

```markdown
> यह भी देखें: `example`।
```

---

### id

```markdown
> Lihat juga: `example`.
```

---

### it

```markdown
> Vedi anche: `example`.
```

---

### ja

```markdown
> 参照: `example`。
```

---

### ko

```markdown
> 관련 항목: `example`.
```

---

### lo

```markdown
> ເບິ່ງຕື່ມ: `example`.
```

---

### ml

```markdown
> ഇതും കാണുക: `example`.
```

---

### nb

```markdown
> Se også: `example`.
```

---

### ne

```markdown
> हेर्नुहोस् पनि: `example`।
```

---

### nl

```markdown
> Zie ook: `example`.
```

---

### no

```markdown
> Se også: `example`.
```

---

### pl

```markdown
> Zobacz także: `example`.
```

---

### pt_BR

```markdown
> Veja também: `example`.
```

---

### pt_PT

```markdown
> Veja também: `example`.
```

---

### ro

```markdown
> Vezi și: `example`.
```

---

### ru

```markdown
> Смотрите также: `example`.
```

---

### si

```markdown
> මෙයද බලන්න: `example`.
```

---

### sr

```markdown
> Такође погледајте: `example`.
```

---

### sv

```markdown
> Se även: `example`.
```

---

### ta

```markdown
> மேலும் காண்க: `example`.
```

---

### th

```markdown
> ดูเพิ่มเติม: `example`
```

---

### tr

```markdown
> Ayrıca bakınız: `example`.
```

---

### uk

```markdown
> Дивіться також: `example`.
```

---

### uz

```markdown
> Shuningdek qarang: `example`.
```

---

### zh

```markdown
> 另请参阅：`example`。
```

---

### zh_TW

```markdown
> 另請參閱：`example`。
```
